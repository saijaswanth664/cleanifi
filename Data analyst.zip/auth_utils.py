import hashlib
import json
import os

USER_DB_PATH = "users.json"

def hash_password(password):
    """Encodes a password into a secure SHA-256 hash."""
    return hashlib.sha256(password.encode()).hexdigest()

def load_users():
    """Loads the user database from users.json."""
    if not os.path.exists(USER_DB_PATH):
        return {}
    try:
        with open(USER_DB_PATH, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}

def save_users(users):
    """Saves the user database to users.json."""
    try:
        with open(USER_DB_PATH, "w") as f:
            json.dump(users, f, indent=4)
        return True
    except IOError:
        return False

def add_user(username, password):
    """Registers a new user if the username isn't taken."""
    users = load_users()
    username = username.strip().lower()  # Normalize username
    
    if username in users:
        return False, "User already exists!"
    
    users[username] = {
        "display_name": username, # Keep for future if needed
        "password": hash_password(password.strip())
    }
    
    if save_users(users):
        return True, "Account created successfully!"
    else:
        return False, "Error saving user data."

def verify_user(username, password):
    """Verifies credentials against the stored hashes."""
    users = load_users()
    username = username.strip().lower()  # Normalize username
    password = password.strip()
    
    if username not in users:
        return False, "User not found!"
    
    stored_hash = users[username].get("password")
    if stored_hash == hash_password(password):
        return True, "Login successful!"
    else:
        return False, "Incorrect password!"
