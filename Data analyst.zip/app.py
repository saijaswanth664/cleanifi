import streamlit as st
import pandas as pd
import re
from io import BytesIO
import time
import styles
import auth_utils
import config

# ---------------- CUSTOM CSS STYLING ----------------
st.set_page_config(
    page_title="AI Data Cleaning Tool",
    page_icon="✨",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------------- SIDEBAR CONFIG ----------------
with st.sidebar:
    # Small toggle switch for Dark Mode
    # Using session state to persist preference (optional, but toggle handles it in run)
    is_dark_mode = st.toggle("🌙 Dark Mode", value=False)

# Load Modern CSS with Theme
styles.load_css(is_dark_mode)

# ---------------- SESSION STATE INIT ---------------- 
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "show_signup" not in st.session_state:
    st.session_state.show_signup = False

if "df" not in st.session_state:
    st.session_state.df = None

if "original_df" not in st.session_state:
    st.session_state.original_df = None
if "uploaded_original_df" not in st.session_state:
    st.session_state.uploaded_original_df = None

if "original_columns" not in st.session_state:
    st.session_state.original_columns = None

if "columns_cleaned" not in st.session_state:
    st.session_state.columns_cleaned = False

if "renaming_done" not in st.session_state:
    st.session_state.renaming_done = False

if "cleaning_done" not in st.session_state:
    st.session_state.cleaning_done = False

if "uploaded_file_id" not in st.session_state:
    st.session_state.uploaded_file_id = None

# ---------------- HELPER FUNCTIONS ----------------
def clean_column_name(col):
    col = col.lower()
    col = re.sub(r"[^\w\s]", "", col)  # remove special characters
    col = col.strip()
    col = col.replace(" ", "_")
    return col

def login_page():
    """Renders the Login/Signup UI."""
    # Centered layout using columns
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        # Use a container to group elements (styles.py will target this column's internal div)
        with st.container():
            if st.session_state.show_signup:
                # SIGN UP VIEW
                st.markdown('<h1 class="auth-header">Create Account</h1>', unsafe_allow_html=True)
                st.markdown('<p class="auth-subtext">Join thousands of data professionals</p>', unsafe_allow_html=True)
                
                new_user = st.text_input("Username", placeholder="Choose a username")
                new_pass = st.text_input("Password", type="password", placeholder="Choose a password")
                confirm_pass = st.text_input("Confirm Password", type="password", placeholder="Confirm password")
                
                if st.button("✨ Sign Up", type="primary", use_container_width=True):
                    if new_user and new_pass:
                        if new_pass == confirm_pass:
                            with st.spinner("Creating account..."):
                                success, message = auth_utils.add_user(new_user, new_pass)
                                if success:
                                    st.success(message)
                                    time.sleep(1)
                                    st.session_state.show_signup = False
                                    st.rerun()
                                else:
                                    st.error(f"❌ {message}")
                        else:
                            st.error("❌ Passwords do not match")
                    else:
                        st.error("❌ Please fill in all fields")
                
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("Already have an account? Log In", use_container_width=True):
                    st.session_state.show_signup = False
                    st.rerun()
                    
            else:
                # LOGIN VIEW
                st.markdown('<h1 class="auth-header">Welcome Back</h1>', unsafe_allow_html=True)
                st.markdown('<p class="auth-subtext">Sign in to continue data cleaning</p>', unsafe_allow_html=True)
                
                # --- GOOGLE SIGN IN ---
                st.markdown('<div class="google-btn-container">', unsafe_allow_html=True)
                if st.button("Sign in with Google", use_container_width=True, key="google_login_btn"):
                    if not config.GOOGLE_CLIENT_ID:
                        st.warning("⚠️ **Google Login Not Configured.** Please add your Client ID in `config.py` to enable this feature.")
                    else:
                        with st.spinner("Connecting to Google..."):
                            # This is where the real OAuth redirect would happen
                            # For now, we show that we ARE checking the configuration
                            time.sleep(1.2)
                            # st.session_state.logged_in = True # REMOVED: No more free bypass
                            st.info("Configuration found! Redirecting to Google (Scaffolded)...")
                st.markdown('</div>', unsafe_allow_html=True)
                
                with st.expander("ℹ️ How to enable real Google Login"):
                    st.write("""
                    To connect this to real Google accounts:
                    1. Go to [Google Cloud Console](https://console.cloud.google.com/).
                    2. Create a project and set up **OAuth 2.0 Client IDs**.
                    3. Add your `CLIENT_ID` to this app's configuration.
                    """)

                st.markdown('<div class="auth-divider">OR</div>', unsafe_allow_html=True)
                
                # --- MANUAL LOGIN ---
                username = st.text_input("Username", placeholder="Enter your username")
                password = st.text_input("Password", type="password", placeholder="Enter your password")
                
                if st.button("🚀 Log In", type="primary", use_container_width=True):
                    if username and password:
                        with st.spinner("Authenticating..."):
                            success, message = auth_utils.verify_user(username, password)
                            if success:
                                st.session_state.logged_in = True
                                st.rerun()
                            else:
                                st.error(f"❌ {message}")
                    else:
                        st.error("❌ Please enter username and password")
                
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("New here? Create Account", use_container_width=True):
                    st.session_state.show_signup = True
                    st.rerun()

def main_app():
    """Renders the Main Data Cleaning Tool."""
    styles.hero_section()
    
    # ---------------- SIDEBAR ---------------- 
    with st.sidebar:
        # Visible sidebar header and brief instructions (styled)
        st.title("AI Data Cleaner")
        st.caption("Monitor progress and quick controls")
    
        # --- Sidebar: Compact Progress Indicator ---
        try:
            uploaded = st.session_state.uploaded_file_id is not None
            cols_done = bool(st.session_state.columns_cleaned)
            cleaned = bool(st.session_state.cleaning_done)
        except Exception:
            uploaded = False
            cols_done = False
            cleaned = False
    
        steps = [
            ("Upload file", uploaded),
            ("Row & Column Management", uploaded and len(st.session_state.df) > 0),
            ("Manual Renaming", st.session_state.renaming_done),
            ("Apply cleaning", cleaned)
        ]
        completed = sum(1 for s in steps if s[1])
        total_steps = len(steps)
        pct = int((completed / total_steps) * 100) if total_steps > 0 else 0
    
        st.write(f"**Progress** ({completed}/{total_steps})")
        st.progress(pct / 100)
        for s_name, s_done in steps:
            st.write(f"{'✅' if s_done else '▫️'} {s_name}")
    
        # Reset button to clear session and restart
        if st.button("🔄 Reset App", use_container_width=True):
            keys_to_clear = [
                "df", "original_df", "original_columns",
                "columns_cleaned", "renaming_done", "cleaning_done", "uploaded_file_id"
            ]
            for k in keys_to_clear:
                if k in st.session_state:
                    del st.session_state[k]
            # Reinitialize defaults
            st.session_state.df = None
            st.session_state.original_df = None
            st.session_state.original_columns = None
            st.session_state.columns_cleaned = False
            st.session_state.renaming_done = False
            st.session_state.cleaning_done = False
            st.session_state.uploaded_file_id = None
            st.success("Application state has been reset.")
            st.rerun()
    
        st.markdown("---")
        
        # File info with professional cards
        if st.session_state.df is not None:
            st.markdown("""
            <div style="text-align: center; padding: 1rem 0;">
                <h3 style="color: #667eea; margin: 0;">📊 Dataset Info</h3>
            </div>
            """, unsafe_allow_html=True)
            df = st.session_state.df
            
            # Create metric cards
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(styles.feature_card("📊", "Rows", f"{len(df):,}"), unsafe_allow_html=True)
            with col2:
                st.markdown(styles.feature_card("📑", "Columns", f"{len(df.columns)}"), unsafe_allow_html=True)
            st.markdown("---")
        
        st.markdown("---")
        
        # Professional tips section
        st.markdown("""
        <div class="pro-tips">
            <h4>💡 Pro Tips</h4>
            <ul>
                <li>Upload Excel (.xlsx) files only</li>
                <li>Review AI suggestions before applying</li>
                <li>Download cleaned data when done</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # LOGOUT BUTTON
        if st.button("🔒 Log Out", use_container_width=True):
            st.session_state.logged_in = False
            st.rerun()
    
    
    # ---------------- FILE UPLOAD ----------------
    styles.step_header(1, "Upload Excel File", "Upload your dataset to begin cleaning")
    
    uploaded_file = st.file_uploader(
        "Choose an Excel file (.xlsx)",
        type=["xlsx"],
        help="Upload your Excel file to begin the cleaning process",
        label_visibility="collapsed"
    )
    
    if uploaded_file is not None:
        st.markdown(styles.success_banner(f"File uploaded successfully: {uploaded_file.name}"), unsafe_allow_html=True)
    
    # ---------------- READ FILE ONCE ----------------
    # Reset session state when a new file is uploaded
    if uploaded_file is not None:
        # Check if this is a new file using a stable ID (name and size)
        # id(uploaded_file) changes every rerun in Streamlit, causing resets.
        current_file_id = f"{uploaded_file.name}_{uploaded_file.size}"
        if st.session_state.uploaded_file_id != current_file_id:
            # New file uploaded - reset everything
            try:
                st.session_state.df = pd.read_excel(uploaded_file)
                st.session_state.uploaded_original_df = st.session_state.df.copy()
                st.session_state.original_columns = st.session_state.df.columns.tolist()
                st.session_state.columns_cleaned = False
                st.session_state.cleaning_done = False
                st.session_state.uploaded_file_id = current_file_id
            except Exception as e:
                st.error(f"Error reading Excel file: {str(e)}")
                st.session_state.df = None
    
    # ---------------- MAIN LOGIC ----------------
    if st.session_state.df is not None:
    
        df = st.session_state.df
    
        # -------- STEP 1: ORIGINAL DATA --------
        st.markdown("---")
        styles.step_header(2, "Dataset Preview", "Review statistics and raw data")
        
        # Dataset summary cards
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.markdown(styles.feature_card("📊", "Total Rows", f"{len(df):,}"), unsafe_allow_html=True)
        with col2:
            st.markdown(styles.feature_card("📑", "Total Columns", f"{len(df.columns)}"), unsafe_allow_html=True)
        with col3:
            total_cells = df.size
            st.markdown(styles.feature_card("🔢", "Total Cells", f"{total_cells:,}"), unsafe_allow_html=True)
        with col4:
            missing_total = df.isnull().sum().sum()
            st.markdown(styles.feature_card("🚨", "Missing Values", f"{missing_total:,}"), unsafe_allow_html=True)
        
        # Show original dataframe if available, otherwise show current
        with st.expander("📊 View Full Dataset", expanded=False):
            if st.session_state.uploaded_original_df is not None:
                st.dataframe(st.session_state.uploaded_original_df, use_container_width=True, height=300)
            else:
                st.dataframe(df, use_container_width=True, height=300)
    
        # -------- STEP 3: ROW & COLUMN MANAGEMENT --------
        st.markdown("---")
        styles.step_header(3, "Row & Column Management", "Delete unnecessary rows or columns")
        
        col_del, row_del = st.columns(2)
        
        with col_del:
            st.markdown("#### 🗑️ Delete Columns")
            with st.container():
                # Add some spacing to align with the radio button on the right
                st.markdown("<div style='height: 15px;'></div>", unsafe_allow_html=True)
                cols_to_delete = st.multiselect(
                    "Select columns to delete",
                    options=df.columns.tolist(),
                    key="cols_to_delete_multiselect"
                )
                # Add more spacing to align with the number inputs on the right
                st.markdown("<div style='height: 72px;'></div>", unsafe_allow_html=True)
                
                if st.button("❌ Remove Selected Columns", use_container_width=True, type="secondary"):
                    if cols_to_delete:
                        st.session_state.df = st.session_state.df.drop(columns=cols_to_delete)
                        st.session_state.original_columns = st.session_state.df.columns.tolist()
                        st.success(f"✅ Removed columns: {', '.join(cols_to_delete)}")
                        time.sleep(0.5)
                        st.rerun()
                    else:
                        st.warning("Please select at least one column to delete.")
                    
        with row_del:
            st.markdown("#### 🗑️ Delete Rows")
            with st.container():
                delete_mode = st.radio(
                    "Delete rows by:",
                    ["Range", "Specific Indices"],
                    horizontal=True,
                    key="row_delete_mode"
                )
                
                if delete_mode == "Range":
                    col_start, col_end = st.columns(2)
                    with col_start:
                        start_idx = st.number_input("Start Index", min_value=0, max_value=max(0, len(df)-1), value=0, step=1)
                    with col_end:
                        end_idx = st.number_input("End Index", min_value=0, max_value=max(0, len(df)-1), value=min(5, max(0, len(df)-1)), step=1)
                    
                    if st.button("❌ Remove Rows in Range", use_container_width=True, type="secondary"):
                        if start_idx <= end_idx:
                            rows_before = len(st.session_state.df)
                            target_indices = st.session_state.df.index[start_idx:end_idx+1]
                            st.session_state.df = st.session_state.df.drop(index=target_indices)
                            rows_after = len(st.session_state.df)
                            st.success(f"✅ Removed {rows_before - rows_after} rows.")
                            time.sleep(0.5)
                            st.rerun()
                        else:
                            st.error("Start index must be less than or equal to end index.")
                
                else:
                    indices_str = st.text_input("Enter row indices (comma-separated, e.g. 0, 2, 5)", placeholder="0, 2, 4")
                    # Add spacer to match the height of number inputs in Range mode
                    st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
                    if st.button("❌ Remove Specific Rows", use_container_width=True, type="secondary"):
                        if indices_str:
                            try:
                                indices = [int(i.strip()) for i in indices_str.split(",") if i.strip().isdigit()]
                                valid_indices = [i for i in indices if i in st.session_state.df.index]
                                if valid_indices:
                                    rows_before = len(st.session_state.df)
                                    st.session_state.df = st.session_state.df.drop(index=valid_indices)
                                    rows_after = len(st.session_state.df)
                                    st.success(f"✅ Removed {rows_before - rows_after} rows.")
                                    time.sleep(0.5)
                                    st.rerun()
                                else:
                                    st.warning("No valid indices found in the current dataset.")
                            except Exception as e:
                                st.error(f"Error parsing indices: {e}")
                        else:
                            st.warning("Please enter at least one row index.")

        # -------- STEP 4: MANUAL COLUMN & ROW RENAMING --------
        st.markdown("---")
        styles.step_header(4, "Manual Column & Row Renaming", "Customize names and row labels")
        
        if not st.session_state.renaming_done:
            # Use columns from current df
            current_cols = df.columns.tolist()
            
            # 1. COLUMN RENAMING section
            st.markdown("### ✏️ Rename Columns (Optional)")
            st.info("💡 You can manually edit the column names below. We've suggested clean versions.")
            
            new_col_names = {}
            # Display items in columns for better density, or a list like the screenshot
            for col in current_cols:
                suggested = clean_column_name(col)
                new_col_names[col] = st.text_input(
                    f"Original: `{col}`",
                    value=suggested,
                    key=f"rename_col_{col}"
                )
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            # 2. ROW RENAMING section
            st.markdown("### 🏷️ Rename Rows (Index)")
            row_rename_option = st.radio(
                "How would you like to rename rows?",
                ["Keep Current Indices", "Add Prefix", "Reset to 1-based"],
                horizontal=True
            )
            
            row_prefix = ""
            if row_rename_option == "Add Prefix":
                row_prefix = st.text_input("Enter prefix (e.g., 'Row_')", value="Row_")
            
            col1, col2 = st.columns([1, 1])
            with col1:
                if st.button("✅ Apply Names & Proceed", use_container_width=True, type="primary"):
                    # Apply Column Renames
                    # Check for duplicates in new names
                    final_names = list(new_col_names.values())
                    if len(final_names) != len(set(final_names)):
                        st.warning("⚠️ Warning: Some new column names are duplicates. Pandas will add suffixes.")
                    
                    # Rename columns in place
                    df.rename(columns=new_col_names, inplace=True)
                    
                    # Apply Row Renames
                    if row_rename_option == "Add Prefix" and row_prefix:
                        df.index = [f"{row_prefix}{i}" for i in range(len(df))]
                    elif row_rename_option == "Reset to 1-based":
                        df.index = range(1, len(df) + 1)
                    
                    st.session_state.df = df
                    st.session_state.original_columns = df.columns.tolist()
                    st.session_state.renaming_done = True
                    st.success("✅ Renaming applied successfully!")
                    time.sleep(0.5)
                    st.rerun()
            with col2:
                if st.button("⏭️ Skip Renaming", use_container_width=True):
                    st.session_state.renaming_done = True
                    st.rerun()
        else:
            st.success("✅ Dataset columns and rows have been renamed")
            if st.button("🔄 Edit Names Again", type="secondary"):
                st.session_state.renaming_done = False
                st.rerun()
            with st.expander("📋 View Current Names"):
                st.write("**Columns:**")
                st.write(", ".join(st.session_state.df.columns.tolist()))
                st.write("**Indices:**")
                st.write(f"Showing first 5: {list(st.session_state.df.index[:5])}")

        # -------- STEP 5: MISSING VALUE ANALYSIS --------
        st.markdown("---")
        styles.step_header(5, "Missing Value Analysis", "Analyze and identify missing values")
    
        missing_summary = []
    
        # Use the current dataframe from session state for analysis.
        current_df = st.session_state.df
        analysis_df = current_df.copy()
        try:
            analysis_df.columns = [clean_column_name(c) for c in analysis_df.columns]
        except Exception:
            analysis_df = current_df.copy()
    
        for col in analysis_df.columns:
            missing_count = analysis_df[col].isnull().sum()
            if pd.api.types.is_numeric_dtype(analysis_df[col]):
                dtype = "Numeric"
            elif pd.api.types.is_datetime64_any_dtype(analysis_df[col]) or "date" in col.lower() or "time" in col.lower():
                dtype = "DateTime"
            else:
                dtype = "Text"
            total_rows = len(analysis_df)
            missing_pct = (missing_count / total_rows * 100) if total_rows > 0 else 0
    
            if missing_count > 0:
                missing_summary.append({
                    "Column Name": col,
                    "Data Type": dtype,
                    "Missing Values": missing_count,
                    "Missing %": f"{missing_pct:.2f}%",
                    "Total Rows": total_rows
                })
    
        # Check if dataframe is empty
        if len(current_df) == 0:
            st.warning("⚠️ The dataset is empty. Please upload a file with data.")
        elif len(missing_summary) == 0:
            st.success("🎉 No missing values detected! Your data is clean.")
        else:
            missing_df = pd.DataFrame(missing_summary)
            
            # Visual summary
            total_missing = sum([row["Missing Values"] for row in missing_summary])
            total_cells = current_df.size
            missing_percentage = (total_missing / total_cells * 100) if total_cells > 0 else 0
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Columns with Missing Values", len(missing_summary))
            with col2:
                st.metric("Total Missing Cells", f"{total_missing:,} ({missing_percentage:.2f}%)")
            
            # Progress bar
            st.markdown(f"""
            <div class="progress-bar">
                <div class="progress-fill" style="width: {100-missing_percentage}%"></div>
            </div>
            <p style="text-align: center; margin-top: 0.5rem;">Data Completeness: {100-missing_percentage:.2f}%</p>
            """, unsafe_allow_html=True)
            
            st.markdown("#### 📊 Missing Values by Column")
            st.dataframe(missing_df, use_container_width=True, height=200)
    
            # -------- STEP 6: AI SUGGESTIONS --------
            st.markdown("---")
            styles.step_header(6, "AI Suggestions", "Review and apply cleaning recommendations")
            st.info("💡 Review AI recommendations below and choose cleaning methods.")
    
            cleaning_choices = {}
            type_choices = {}       # Store integer/float preference for numeric columns
            precision_choices = {}  # Store decimal precision for numeric columns
    
            for idx, row in enumerate(missing_summary):
                col = row["Column Name"]
                dtype = row["Data Type"]
                missing_count = row["Missing Values"]
    
                with st.container():
                    st.markdown(f"#### Column {idx+1}: `{col}`")
                    
                    col1, col2 = st.columns([2, 1])
                    with col1:
                        if dtype == "Numeric":
                            ai_suggestion = "Median (recommended to reduce outliers)"
                            options = ["Mean", "Median", "Mode", "Delete Rows", "Keep As Is"]
                            st.markdown(f"**Data Type:** 🔢 Numeric | **Missing:** {missing_count} values")
                        elif dtype == "DateTime":
                            ai_suggestion = "Forward Fill (common for temporal data)"
                            options = ["Forward Fill", "Backward Fill", "Most Frequent", "Keep NaN", "Delete Rows"]
                            st.markdown(f"**Data Type:** 📅 DateTime | **Missing:** {missing_count} values")
                        else:
                            ai_suggestion = "Mode (most frequent value)"
                            options = ["Mode", "Fill with 'Unknown'", "Delete Rows", "Keep As Is"]
                            st.markdown(f"**Data Type:** 📝 Text | **Missing:** {missing_count} values")
                        
                        st.markdown(f"**🤖 AI Recommendation:** {ai_suggestion}")
                    
                    with col2:
                        choice = st.selectbox(
                            f"Choose method",
                            options,
                            key=col,
                            label_visibility="collapsed"
                        )
                    
                    cleaning_choices[col] = choice
                    
                    # Add integer/float selection and precision slider for numeric columns
                    if dtype == "Numeric":
                        col_type, col_prec = st.columns(2)
                        with col_type:
                            type_choice = st.radio(
                                f"Output Type",
                                ["Integer", "Float"],
                                key=f"type_{col}",
                                horizontal=True,
                                index=1  # Default to Float
                            )
                            type_choices[col] = type_choice
                        
                        if type_choice == "Float":
                            with col_prec:
                                precision = st.slider(
                                    "Decimals",
                                    min_value=0,
                                    max_value=6,
                                    value=2,
                                    key=f"precision_{col}"
                                )
                                precision_choices[col] = precision
                    
                    st.markdown("---")
    
            # -------- STEP 5: APPLY CLEANING --------
            st.markdown("---")
            st.markdown("""
            <div style="text-align: center; padding: 2rem 0;">
                <h2 style="color: #2d3748; margin: 0; display: flex; align-items: center; justify-content: center;">
                    <span style="font-size: 2rem; margin-right: 0.5rem;">🚀</span>
                    <span>Ready to Clean!</span>
                </h2>
                <p style="color: #718096; margin-top: 0.5rem;">Click the button below to apply all selected cleaning methods</p>
            </div>
            """, unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns([1, 2, 1])
            with col2:
                if st.button("✨ Apply Cleaning", use_container_width=True, type="primary"):
                    # Use the current dataframe from session state
                    df = st.session_state.df.copy()
                    
                    rows_deleted = 0
                    cells_modified = 0
    
                    for col, method in cleaning_choices.items():
                        # The UI/analysis uses snake_case column names (analysis_df). The
                        # stored dataframe (`df`) may still have original column names
                        # (e.g., 'Age' or 'Purchase Amount (USD)'). Try to map the
                        # snake_case name back to the original column name before
                        # skipping.
                        target_col = col
                        if col not in df.columns:
                            # find the first original column whose cleaned name matches
                            matches = [c for c in df.columns if clean_column_name(c) == col]
                            if len(matches) > 0:
                                target_col = matches[0]
                                st.info(f"Mapping analysis column '{col}' -> original column '{target_col}'")
                            else:
                                st.warning(f"Column '{col}' not found. Skipping...")
                                continue
    
                        if method == "Keep As Is" or method == "Keep NaN":
                            # Skip this column - don't modify it
                            continue
                        
                        elif method == "Forward Fill":
                            missing_before = df[target_col].isnull().sum()
                            df[target_col].ffill(inplace=True)
                            cells_modified += missing_before
                            
                        elif method == "Backward Fill":
                            missing_before = df[target_col].isnull().sum()
                            df[target_col].bfill(inplace=True)
                            cells_modified += missing_before
    
                        elif method == "Mean":
                            if not pd.api.types.is_numeric_dtype(df[target_col]):
                                st.warning(f"Cannot calculate mean for non-numeric column '{target_col}'. Skipping...")
                                continue
                            value = df[target_col].mean()
                            if pd.notna(value):
                                # Convert to integer or float based on user selection
                                fill_type = type_choices.get(col, "Float")
                                if fill_type == "Integer":
                                    value = int(round(value))
                                    df[target_col].fillna(value, inplace=True)
                                else:
                                    prec = precision_choices.get(col, 2)
                                    value = round(float(value), prec)
                                    df[target_col].fillna(value, inplace=True)
                                    # Also round existing values in the column to maintain consistency
                                    df[target_col] = df[target_col].round(prec)
                                    
                                missing_before = df[target_col].isnull().sum()
                                cells_modified += missing_before
                            else:
                                st.warning(f"Cannot calculate mean for column '{col}' (all values are NaN). Skipping...")
    
                        elif method == "Median":
                            if not pd.api.types.is_numeric_dtype(df[target_col]):
                                st.warning(f"Cannot calculate median for non-numeric column '{target_col}'. Skipping...")
                                continue
                            value = df[target_col].median()
                            if pd.notna(value):
                                # Convert to integer or float based on user selection
                                fill_type = type_choices.get(col, "Float")
                                if fill_type == "Integer":
                                    value = int(round(value))
                                    df[target_col].fillna(value, inplace=True)
                                else:
                                    prec = precision_choices.get(col, 2)
                                    value = round(float(value), prec)
                                    df[target_col].fillna(value, inplace=True)
                                    # Also round existing values in the column
                                    df[target_col] = df[target_col].round(prec)
                                    
                                missing_before = df[target_col].isnull().sum()
                                cells_modified += missing_before
                            else:
                                st.warning(f"Cannot calculate median for column '{col}' (all values are NaN). Skipping...")
    
                        elif method == "Mode" or method == "Most Frequent":
                            # Remove NaN values before calculating mode
                            non_null_values = df[target_col].dropna()
                            if len(non_null_values) == 0:
                                st.warning(f"Cannot calculate mode for column '{target_col}' (all values are NaN). Skipping...")
                                continue
                            mode_values = df[target_col].mode()
                            if len(mode_values) > 0:
                                value = mode_values[0]
                                missing_before = df[target_col].isnull().sum()
                                df[target_col].fillna(value, inplace=True)
                                cells_modified += missing_before
                            else:
                                st.warning(f"Cannot calculate mode for column '{col}' (no mode available). Skipping...")
    
                        elif method == "Fill with 'Unknown'":
                            missing_before = df[target_col].isnull().sum()
                            df[target_col].fillna("Unknown", inplace=True)
                            cells_modified += missing_before
    
                        elif method == "Delete Rows":
                            before = len(df)
                            df.dropna(subset=[target_col], inplace=True)
                            rows_deleted += before - len(df)
    
                    st.session_state.df = df
                    # After applying cleaning methods, convert final column names to snake_case
                    # so the final dataset uses consistent pandas-style names.
                    try:
                        new_cols = []
                        seen = {}
                        for c in df.columns:
                            base = clean_column_name(c)
                            if base in seen:
                                seen[base] += 1
                                new_name = f"{base}_{seen[base]}"
                            else:
                                seen[base] = 1
                                new_name = base
                            new_cols.append(new_name)
                        df.columns = new_cols
                    except Exception:
                        pass
    
                    st.session_state.df = df
                    st.session_state.columns_cleaned = True
                    st.session_state.cleaning_done = True
    
                    # Show summary
                    if cells_modified > 0 or rows_deleted > 0:
                        summary_msg = f"✅ Data cleaning applied successfully!\n"
                        if cells_modified > 0:
                            summary_msg += f"• {cells_modified} missing values filled\n"
                        if rows_deleted > 0:
                            summary_msg += f"• {rows_deleted} rows deleted"
                        st.success(summary_msg)
                    else:
                        st.info("No changes were applied (all columns set to 'Keep As Is' or no valid cleaning method selected).")
    
        # -------- STEP 7: FINAL OUTPUT --------
        if st.session_state.cleaning_done:
            st.markdown("---")
            st.markdown("""
            <div class="success-banner">
                <h1>
                    <span>🎉</span>
                    Cleaning Complete!
                </h1>
                <p>Your data has been successfully cleaned and is ready to download</p>
            </div>
            """, unsafe_allow_html=True)
            
            # -------- DATA QUALITY SCORE --------
            # Build final_df from current working df
            final_df = st.session_state.df.copy()
            total_cells = final_df.size
            missing_after = final_df.isnull().sum().sum()
            quality_score = round(100 - (missing_after / total_cells * 100), 2) if total_cells > 0 else 100
            
            # Quality score with visual
            col1, col2, col3 = st.columns([1, 2, 1])
            with col2:
                st.markdown("### 📈 Data Quality Score")
                st.metric("Quality Score", f"{quality_score}%", delta=f"{quality_score-50:.1f}%")
                
                # Quality progress bar
                quality_color = "#28a745" if quality_score >= 90 else "#ffc107" if quality_score >= 70 else "#dc3545"
                st.markdown(f"""
                <div class="progress-bar">
                    <div class="progress-fill" style="width: {quality_score}%; background: {quality_color};"></div>
                </div>
                """, unsafe_allow_html=True)
            
            # Dataset comparison
            st.markdown("### 📊 Dataset Comparison")
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                original_rows = len(st.session_state.uploaded_original_df) if st.session_state.uploaded_original_df is not None else len(final_df)
                st.metric("Rows", f"{len(final_df):,}", delta=f"{len(final_df) - original_rows}")
            with col2:
                original_cols_count = len(st.session_state.uploaded_original_df.columns) if st.session_state.uploaded_original_df is not None else len(final_df.columns)
                st.metric("Columns", len(final_df.columns), delta=f"{len(final_df.columns) - original_cols_count}")
            with col3:
                original_missing = st.session_state.uploaded_original_df.isnull().sum().sum() if st.session_state.uploaded_original_df is not None else 0
                st.metric("Missing Values", f"{missing_after:,}", delta=f"{missing_after - original_missing}", delta_color="inverse")
            with col4:
                st.metric("Data Completeness", f"{quality_score}%")
            
            # Final dataset preview
            st.markdown("### 📋 Final Cleaned Dataset")
            with st.expander("View Cleaned Data", expanded=True):
                st.dataframe(final_df, use_container_width=True, height=400)
    
            # -------- CLEANING REPORT --------
            st.markdown("### 📝 Cleaning Report")
            report_col1, report_col2 = st.columns(2)
            with report_col1:
                st.markdown("""
                <div class="success-box">
                    <h4>✅ Completed Steps</h4>
                    <ul>
                        <li>Column name standardization applied</li>
                        <li>Missing values handled using AI-assisted rules</li>
                        <li>Human-in-the-loop decision making enabled</li>
                    </ul>
                </div>
                """, unsafe_allow_html=True)
            with report_col2:
                st.markdown(f"""
                <div class="info-box">
                    <h4>📊 Statistics</h4>
                    <ul>
                        <li>Total cells processed: {total_cells:,}</li>
                        <li>Missing values remaining: {missing_after:,}</li>
                        <li>Data quality: {quality_score}%</li>
                    </ul>
                </div>
                """, unsafe_allow_html=True)
    
            # -------- DOWNLOAD CLEANED EXCEL --------
            st.markdown("---")
            st.markdown("### 💾 Download Cleaned Excel File")
            
            output = BytesIO()
            try:
                with st.spinner("Preparing download..."):
                    with pd.ExcelWriter(output, engine='openpyxl') as writer:
                        st.session_state.df.to_excel(writer, index=False, sheet_name='Cleaned Data')
                    output.seek(0)  # Reset pointer to beginning of file
                    
                    col1, col2, col3 = st.columns([1, 2, 1])
                    with col2:
                        st.download_button(
                            label="📥 Download Cleaned Excel",
                            data=output.getvalue(),
                            file_name="cleaned_data.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            use_container_width=True,
                            type="primary"
                        )
            except Exception as e:
                st.error(f"❌ Error creating Excel file: {str(e)}")

# ---------------- APP CONTROL FLOW ----------------
if st.session_state.logged_in:
    main_app()
else:
    login_page()