import streamlit as st
import pandas as pd
import re
from io import BytesIO

# ---------------- CUSTOM CSS STYLING ----------------
st.set_page_config(
    page_title="AI Data Cleaning Tool",
    page_icon="🧹",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for Professional UI with Theme Support
st.markdown("""
    <style>
    /* Import Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
    
    /* CSS Variables for Light Theme (Default) */
    :root {
        --bg-primary: #ffffff;
        --bg-secondary: #f8f9fa;
        --bg-tertiary: #e9ecef;
        --text-primary: #2d3748;
        --text-secondary: #718096;
        --border-color: rgba(102, 126, 234, 0.1);
        --shadow-color: rgba(0, 0, 0, 0.08);
        --shadow-hover: rgba(102, 126, 234, 0.15);
        --card-bg: #ffffff;
        --sidebar-bg: linear-gradient(180deg, #f8f9fa 0%, #ffffff 100%);
        --step-bg: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        --scrollbar-track: #f1f1f1;
    }
    
    /* CSS Variables for Dark Theme */
    [data-theme="dark"] {
        --bg-primary: #1a1a1a;
        --bg-secondary: #2d2d2d;
        --bg-tertiary: #3d3d3d;
        --text-primary: #e2e8f0;
        --text-secondary: #a0aec0;
        --border-color: rgba(102, 126, 234, 0.3);
        --shadow-color: rgba(0, 0, 0, 0.3);
        --shadow-hover: rgba(102, 126, 234, 0.2);
        --card-bg: #2d2d2d;
        --sidebar-bg: linear-gradient(180deg, #2d2d2d 0%, #1a1a1a 100%);
        --step-bg: linear-gradient(135deg, #2d2d2d 0%, #1a1a1a 100%);
        --scrollbar-track: #3d3d3d;
    }
    
    /* Apply theme to main container */
    .main {
        background-color: var(--bg-primary) !important;
        color: var(--text-primary) !important;
    }

    /* Page background: Cool Slate Gradient (Corporate - Cool Slate A) */
    body {
        /* Slightly deeper cool-slate background for better contrast */
        background-color: #e6eef6;
        /* keep attachment for potential subtle effects on long pages */
        background-attachment: fixed;
        color-scheme: light;
    }

    /* Main container - elevated white card for contrast against the slate background */
    .main .block-container {
        background-color: rgba(255,255,255,0.985) !important;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(32,41,54,0.06);
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1200px;
    }

    /* Header accent tuned for the cool-slate vibe */
    .main-header {
        box-shadow: 0 12px 50px rgba(32,41,54,0.06);
    }
    
    /* Global Styles */
    * {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }
    
    /* Main Container */
    .main .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1200px;
    }
    
    /* Professional Header */
    .main-header {
        background: linear-gradient(135deg, rgba(102,126,234,0.95) 0%, rgba(118,75,162,0.95) 50%, rgba(240,147,251,0.95) 100%);
        padding: 3.5rem 2rem;
        border-radius: 18px;
        color: white;
        margin-bottom: 2.5rem;
        text-align: center;
        box-shadow: 0 12px 50px rgba(102, 126, 234, 0.18);
        position: relative;
        overflow: hidden;
    }
    .main-header::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        animation: pulse 4s ease-in-out infinite;
    }
    @keyframes pulse {
        0%, 100% { transform: scale(1); opacity: 0.5; }
        50% { transform: scale(1.1); opacity: 0.8; }
    }
    .main-header h1 {
        color: white;
        margin: 0;
        font-size: 3rem;
        font-weight: 800;
        letter-spacing: -0.6px;
        text-shadow: 0 6px 30px rgba(0,0,0,0.12);
        position: relative;
        z-index: 2;
    }
    .main-header p {
        color: rgba(255,255,255,0.95);
        margin-top: 0.8rem;
        font-size: 1.05rem;
        font-weight: 500;
        position: relative;
        z-index: 2;
    }

    /* Decorative floating shapes in header */
    .main-header .dot { position: absolute; border-radius: 50%; opacity: 0.15; }
    .main-header .dot.one { width: 220px; height: 220px; right: -40px; top: -50px; background: white; }
    .main-header .dot.two { width: 120px; height: 120px; left: -30px; bottom: -30px; background: #ffffff; opacity: 0.06; }
    
    /* Step Containers */
    .step-container {
        background: var(--step-bg);
        padding: 2rem;
        border-radius: 15px;
        margin: 1.5rem 0;
        border-left: 5px solid #667eea;
        box-shadow: 0 4px 15px var(--shadow-color);
        transition: all 0.3s ease;
        color: var(--text-primary);
    }
    .step-container:hover {
        box-shadow: 0 6px 20px var(--shadow-hover);
        transform: translateY(-2px);
    }
    
    /* Metric Cards */
    .metric-card {
        background: var(--card-bg);
        padding: 1.8rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px var(--shadow-color);
        text-align: center;
        transition: all 0.3s ease;
        border: 1px solid var(--border-color);
        color: var(--text-primary);
    }
    .metric-card .label { font-size: 0.85rem; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.6px; }
    .metric-card .value { font-size: 1.6rem; font-weight: 800; color: #4250d8; }
    .metric-card:hover {
        box-shadow: 0 8px 25px var(--shadow-hover);
        transform: translateY(-5px);
    }
    
    /* Info Boxes */
    .success-box {
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        border: 2px solid #28a745;
        border-radius: 12px;
        padding: 1.2rem;
        color: #155724;
        box-shadow: 0 2px 10px rgba(40, 167, 69, 0.1);
    }
    .info-box {
        background: linear-gradient(135deg, #d1ecf1 0%, #bee5eb 100%);
        border: 2px solid #17a2b8;
        border-radius: 12px;
        padding: 1.2rem;
        color: #0c5460;
        box-shadow: 0 2px 10px rgba(23, 162, 184, 0.1);
    }
    .warning-box {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
        border: 2px solid #ffc107;
        border-radius: 12px;
        padding: 1.2rem;
        color: #856404;
        box-shadow: 0 2px 10px rgba(255, 193, 7, 0.1);
    }
    
    /* Professional Buttons */
    .stButton>button {
        width: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        font-weight: 600;
        font-size: 1rem;
        border: none;
        border-radius: 12px;
        padding: 0.75rem 1.5rem;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        letter-spacing: 0.3px;
    }
    .stButton>button:focus { outline: none; box-shadow: 0 6px 30px rgba(102,126,234,0.18); }
    .stDownloadButton>button { background: linear-gradient(90deg, #2ebf91 0%, #20c997 100%) !important; }
    .stButton>button:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 25px rgba(102, 126, 234, 0.4);
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    }
    .stButton>button:active {
        transform: translateY(-1px);
    }
    
    /* Sidebar Styling */
    .css-1d391kg {
        background: var(--sidebar-bg) !important;
    }
    .sidebar .sidebar-content {
        background: var(--sidebar-bg);
        padding: 1.5rem;
        color: var(--text-primary);
    }
    
    /* Progress Bars */
    .progress-bar {
        height: 30px;
        background: var(--bg-tertiary);
        border-radius: 15px;
        overflow: hidden;
        box-shadow: inset 0 2px 5px var(--shadow-color);
    }
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        transition: width 0.5s ease;
        box-shadow: 0 2px 10px rgba(102, 126, 234, 0.3);
    }
    
    /* Dataframe Styling */
    .dataframe {
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }
    
    /* Section Headers */
    h2, h3 {
        color: var(--text-primary);
        font-weight: 700;
        letter-spacing: -0.3px;
    }
    
    /* Expander Styling */
    .streamlit-expanderHeader {
        background: var(--step-bg);
        border-radius: 10px;
        padding: 1rem;
        font-weight: 600;
        color: var(--text-primary);
    }
    
    /* File Uploader */
    .uploadedFile {
        background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
        border-radius: 10px;
        padding: 1rem;
        border: 2px dashed #2196f3;
    }
    
    /* Selectbox Styling */
    .stSelectbox > div > div {
        background: var(--card-bg);
        border-radius: 10px;
        box-shadow: 0 2px 8px var(--shadow-color);
        color: var(--text-primary);
    }
    
    /* Metric Styling */
    [data-testid="stMetricValue"] {
        font-size: 2rem;
        font-weight: 700;
        color: #667eea;
    }
    [data-testid="stMetricLabel"] {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    /* Success Messages */
    .stSuccess {
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        border-radius: 10px;
        border-left: 4px solid #28a745;
        padding: 1rem;
    }
    
    /* Info Messages */
    .stInfo {
        background: linear-gradient(135deg, #d1ecf1 0%, #bee5eb 100%);
        border-radius: 10px;
        border-left: 4px solid #17a2b8;
        padding: 1rem;
    }
    
    /* Warning Messages */
    .stWarning {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
        border-radius: 10px;
        border-left: 4px solid #ffc107;
        padding: 1rem;
    }
    
    /* Error Messages */
    .stError {
        background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
        border-radius: 10px;
        border-left: 4px solid #dc3545;
        padding: 1rem;
    }
    
    /* Table Styling */
    table {
        border-radius: 10px;
        overflow: hidden;
    }
    
    /* Scrollbar Styling */
    ::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }
    ::-webkit-scrollbar-track {
        background: var(--scrollbar-track);
        border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    }
    
    /* Loading Spinner */
    .stSpinner > div {
        border-color: #667eea transparent transparent transparent;
    }
    
    /* Hide Streamlit branding menu and footer, but keep the header visible so the sidebar toggle is accessible */
    #MainMenu { visibility: hidden; }
    footer { visibility: hidden; }
    /* Keep header visible to allow the built-in sidebar toggle / chevron to show */
    header { visibility: visible; }
    
    /* Smooth Transitions */
    * {
        transition: background-color 0.3s ease, color 0.3s ease;
    }
    
    /* Streamlit Component Theme Support */
    .stMarkdown, .stText, .stDataFrame {
        color: var(--text-primary) !important;
    }
    
    /* Streamlit Main Background - Force override */
    .main .block-container {
        background-color: var(--bg-primary) !important;
    }
    
    /* Streamlit App Root Background */
    .stApp {
        background-color: var(--bg-primary) !important;
    }
    
    /* Streamlit Main Container */
    .main {
        background-color: var(--bg-primary) !important;
    }
    
    /* Streamlit Sidebar - Force override */
    section[data-testid="stSidebar"] {
        background: var(--sidebar-bg) !important;
    }
    
    section[data-testid="stSidebar"] > div {
        background: var(--sidebar-bg) !important;
    }
    
    /* Streamlit Elements */
    .element-container {
        color: var(--text-primary) !important;
    }
    
    /* Streamlit Markdown containers */
    .stMarkdown > div {
        color: var(--text-primary) !important;
    }
    
    /* Streamlit Text elements */
    .stText {
        color: var(--text-primary) !important;
    }
    
    /* Streamlit Dataframe */
    .stDataFrame {
        background-color: var(--card-bg) !important;
        color: var(--text-primary) !important;
    }
    
    /* Streamlit Selectbox */
    .stSelectbox label,
    .stSelectbox > div > div {
        color: var(--text-primary) !important;
        background-color: var(--card-bg) !important;
    }
    
    /* Streamlit Radio */
    .stRadio label {
        color: var(--text-primary) !important;
    }
    
    /* Streamlit Text Input */
    .stTextInput label,
    .stTextInput input {
        color: var(--text-primary) !important;
        background-color: var(--card-bg) !important;
    }
    
    /* Streamlit Slider */
    .stSlider label {
        color: var(--text-primary) !important;
    }
    
    /* Streamlit File Uploader */
    .stFileUploader label {
        color: var(--text-primary) !important;
    }
    
    /* Streamlit Expander */
    .streamlit-expanderHeader {
        background: var(--step-bg) !important;
        color: var(--text-primary) !important;
    }
    
    .streamlit-expanderContent {
        background: var(--bg-primary) !important;
        color: var(--text-primary) !important;
    }
    
    /* Dark theme specific adjustments */
    [data-theme="dark"] {
        background-color: var(--bg-primary) !important;
    }
    
    [data-theme="dark"] .stDataFrame {
        background-color: var(--card-bg) !important;
    }
    
    [data-theme="dark"] .stSelectbox label,
    [data-theme="dark"] .stRadio label,
    [data-theme="dark"] .stTextInput label {
        color: var(--text-primary) !important;
    }
    
    /* Force Streamlit root elements - Dark Theme */
    [data-theme="dark"] .stApp {
        background-color: #1a1a1a !important;
    }
    
    [data-theme="dark"] .main {
        background-color: #1a1a1a !important;
    }
    
    [data-theme="dark"] .main .block-container {
        background-color: #1a1a1a !important;
    }
    
    [data-theme="dark"] section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #2d2d2d 0%, #1a1a1a 100%) !important;
    }
    
    [data-theme="dark"] section[data-testid="stSidebar"] > div {
        background: linear-gradient(180deg, #2d2d2d 0%, #1a1a1a 100%) !important;
    }
    
    [data-theme="dark"] .element-container {
        background-color: transparent !important;
    }
    
    /* Force Streamlit root elements - Light Theme */
    :root:not([data-theme="dark"]) .stApp {
        background-color: #ffffff !important;
    }
    
    :root:not([data-theme="dark"]) .main {
        background-color: #ffffff !important;
    }
    
    :root:not([data-theme="dark"]) .main .block-container {
        background-color: #ffffff !important;
    }
    
    :root:not([data-theme="dark"]) section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #f8f9fa 0%, #ffffff 100%) !important;
    }
    
    :root:not([data-theme="dark"]) section[data-testid="stSidebar"] > div {
        background: linear-gradient(180deg, #f8f9fa 0%, #ffffff 100%) !important;
    }
    
    /* Additional aggressive overrides for dark theme */
    html[data-theme="dark"] body,
    html[data-theme="dark"] .stApp,
    html[data-theme="dark"] .main,
    html[data-theme="dark"] .main .block-container {
        background-color: #1a1a1a !important;
        color: #e2e8f0 !important;
    }
    
    html[data-theme="dark"] section[data-testid="stSidebar"],
    html[data-theme="dark"] section[data-testid="stSidebar"] > div,
    html[data-theme="dark"] section[data-testid="stSidebar"] > div > div {
        background: linear-gradient(180deg, #2d2d2d 0%, #1a1a1a 100%) !important;
    }
    
    /* Additional aggressive overrides for light theme */
    html:not([data-theme="dark"]) body,
    html:not([data-theme="dark"]) .stApp,
    html:not([data-theme="dark"]) .main,
    html:not([data-theme="dark"]) .main .block-container {
        background-color: #ffffff !important;
        color: #2d3748 !important;
    }
    
    html:not([data-theme="dark"]) section[data-testid="stSidebar"],
    html:not([data-theme="dark"]) section[data-testid="stSidebar"] > div,
    html:not([data-theme="dark"]) section[data-testid="stSidebar"] > div > div {
        background: linear-gradient(180deg, #f8f9fa 0%, #ffffff 100%) !important;
    }
    </style>
""", unsafe_allow_html=True)

# ---------------- SESSION STATE INIT ---------------- 
if "df" not in st.session_state:
    st.session_state.df = None

if "original_df" not in st.session_state:
    st.session_state.original_df = None
if "uploaded_original_df" not in st.session_state:
    st.session_state.uploaded_original_df = None

if "original_columns" not in st.session_state:
    st.session_state.original_columns = None

if "columns_cleaned" not in st.session_state:
    st.session_state.columns_cleaned = False

if "cleaning_done" not in st.session_state:
    st.session_state.cleaning_done = False

if "uploaded_file_id" not in st.session_state:
    st.session_state.uploaded_file_id = None

# Theme mode removed - no theme switching stored in session state

# ---------------- THEME APPLICATION REMOVED ----------------
# Theme support and theme-switching JS removed per user request.

# ---------------- PAGE HEADER ---------------- 
st.markdown("""
    <div class="main-header">
        <div class="dot one"></div>
        <div class="dot two"></div>
        <h1>🧹 AI-Based Automatic Data Cleaning Tool</h1>
        <p>Upload an Excel file and clean it without writing any code — fast, safe, and human-in-the-loop.</p>
    </div>
""", unsafe_allow_html=True)

# Progress display removed from main page per user request

# ---------------- SIDEBAR ---------------- 
with st.sidebar:
    # Visible sidebar header and brief instructions (styled)
    st.markdown("""
    <div style="display:flex; align-items:center; gap:0.75rem; padding: 0.75rem 0;">
        <div style="width:44px; height:44px; border-radius:10px; background: linear-gradient(135deg,#667eea,#764ba2); display:flex; align-items:center; justify-content:center; color:white; font-weight:800; font-size:1.1rem;">AI</div>
        <div style="flex:1;">
            <div style="font-weight:700; color:#2d3748;">AI Data Cleaner</div>
            <div style="font-size:0.85rem; color:#6b7280;">Monitor progress and quick controls</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # --- Sidebar: Compact Progress Indicator ---
    try:
        uploaded = st.session_state.uploaded_file_id is not None
        cols_done = bool(st.session_state.columns_cleaned)
        cleaned = bool(st.session_state.cleaning_done)
    except Exception:
        uploaded = False
        cols_done = False
        cleaned = False

    steps = [
        ("Upload file", uploaded),
        ("Column standardization", cols_done),
        ("Apply cleaning", cleaned)
    ]
    completed = sum(1 for s in steps if s[1])
    total_steps = len(steps)
    pct = int((completed / total_steps) * 100) if total_steps > 0 else 0

    st.markdown(f"""
    <div style="padding:0.75rem; border-radius:10px; background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%); border:1px solid rgba(102,126,234,0.06);">
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <div style="font-weight:700; color:#2d3748;">Progress</div>
            <div style="font-size:0.9rem; color:#718096;">{completed} of {total_steps} completed</div>
        </div>
        <div style="margin-top:0.6rem;">
            <div class="progress-bar">
                <div class="progress-fill" style="width: {pct}%;"></div>
            </div>
            <div style="font-size:0.85rem; color:#718096; text-align:center; margin-top:0.4rem;">{pct}%</div>
        </div>
        <div style="margin-top:0.6rem; font-size:0.9rem; color:#495057;">
            <ul style="margin:0; padding-left:1.1rem;">
                {''.join([f"<li style='margin-bottom:0.25rem;'>{'✅' if s[1] else '▫️'} {s[0]}</li>" for s in steps])}
            </ul>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Reset button to clear session and restart
    if st.button("🔄 Reset App", use_container_width=True):
        keys_to_clear = [
            "df", "original_df", "original_columns",
            "columns_cleaned", "cleaning_done", "uploaded_file_id"
        ]
        for k in keys_to_clear:
            if k in st.session_state:
                del st.session_state[k]
        # Reinitialize defaults
        st.session_state.df = None
        st.session_state.original_df = None
        st.session_state.original_columns = None
        st.session_state.columns_cleaned = False
        st.session_state.cleaning_done = False
        st.session_state.uploaded_file_id = None
        st.success("Application state has been reset.")
        st.rerun()

    st.markdown("---")
    
    # Sidebar progress removed — progress is shown on the main page only
    
    # File info with professional cards
    if st.session_state.df is not None:
        st.markdown("""
        <div style="text-align: center; padding: 1rem 0;">
            <h3 style="color: #667eea; margin: 0;">📊 Dataset Info</h3>
        </div>
        """, unsafe_allow_html=True)
        df = st.session_state.df
        
        # Create metric cards
        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
                        padding: 1rem; border-radius: 10px; text-align: center;
                        border: 1px solid rgba(102, 126, 234, 0.2);">
                <div style="font-size: 1.8rem; font-weight: 700; color: #667eea;">{len(df):,}</div>
                <div style="font-size: 0.85rem; color: #718096; text-transform: uppercase; letter-spacing: 0.5px;">Rows</div>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
                        padding: 1rem; border-radius: 10px; text-align: center;
                        border: 1px solid rgba(102, 126, 234, 0.2);">
                <div style="font-size: 1.8rem; font-weight: 700; color: #667eea;">{len(df.columns)}</div>
                <div style="font-size: 0.85rem; color: #718096; text-transform: uppercase; letter-spacing: 0.5px;">Columns</div>
            </div>
            """, unsafe_allow_html=True)
        st.markdown("---")
    
    # Prompt removed per user request
    st.markdown("---")
    
    # Professional tips section
    st.markdown("""
    <div style="background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
                padding: 1.2rem; border-radius: 12px; border-left: 4px solid #2196f3;">
        <h4 style="color: #1976d2; margin-top: 0; margin-bottom: 0.8rem;">💡 Pro Tips</h4>
        <ul style="color: #0d47a1; margin: 0; padding-left: 1.2rem; font-size: 0.9rem;">
            <li style="margin-bottom: 0.5rem;">Upload Excel (.xlsx) files only</li>
            <li style="margin-bottom: 0.5rem;">Review AI suggestions before applying</li>
            <li>Download cleaned data when done</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Footer removed per user request


# ---------------- HELPER FUNCTION ----------------
def clean_column_name(col):
    col = col.lower()
    col = re.sub(r"[^\w\s]", "", col)  # remove special characters
    col = col.strip()
    col = col.replace(" ", "_")
    return col

# ---------------- FILE UPLOAD ----------------
st.markdown("""
<div style="background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            padding: 2rem; border-radius: 15px; margin: 2rem 0;
            border-left: 5px solid #667eea; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
    <h2 style="color: #2d3748; margin-top: 0; display: flex; align-items: center;">
        <span style="font-size: 2rem; margin-right: 0.5rem;">📤</span>
        <span>Step 1: Upload Your Excel File</span>
    </h2>
    <p style="color: #718096; margin-bottom: 0;">Upload your Excel file to begin the intelligent data cleaning process</p>
</div>
""", unsafe_allow_html=True)

uploaded_file = st.file_uploader(
    "Choose an Excel file (.xlsx)",
    type=["xlsx"],
    help="Upload your Excel file to begin the cleaning process",
    label_visibility="collapsed"
)

if uploaded_file is not None:
    st.markdown(f"""
    <div style="background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
                padding: 1.2rem; border-radius: 12px; border-left: 4px solid #28a745;
                margin: 1rem 0; box-shadow: 0 2px 10px rgba(40, 167, 69, 0.1);">
        <div style="display: flex; align-items: center;">
            <span style="font-size: 1.5rem; margin-right: 0.8rem;">✅</span>
            <div>
                <strong style="color: #155724;">File uploaded successfully!</strong><br>
                <span style="color: #155724; font-size: 0.9rem;">📄 {uploaded_file.name}</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

# ---------------- READ FILE ONCE ----------------
# Reset session state when a new file is uploaded
if uploaded_file is not None:
    # Check if this is a new file (different from the one we have)
    current_file_id = id(uploaded_file)
    if st.session_state.uploaded_file_id != current_file_id:
        # New file uploaded - reset everything
        try:
            st.session_state.df = pd.read_excel(uploaded_file)
            st.session_state.uploaded_original_df = st.session_state.df.copy()
            st.session_state.original_columns = st.session_state.df.columns.tolist()
            st.session_state.columns_cleaned = False
            st.session_state.cleaning_done = False
            st.session_state.uploaded_file_id = current_file_id
        except Exception as e:
            st.error(f"Error reading Excel file: {str(e)}")
            st.session_state.df = None

# ---------------- MAIN LOGIC ----------------
if st.session_state.df is not None:

    df = st.session_state.df

    # -------- STEP 1: ORIGINAL DATA --------
    st.markdown("---")
    st.markdown("""
    <div style="background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
                padding: 2rem; border-radius: 15px; margin: 2rem 0;
                border-left: 5px solid #667eea; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
        <h2 style="color: #2d3748; margin-top: 0; display: flex; align-items: center;">
            <span style="font-size: 2rem; margin-right: 0.5rem;">📋</span>
            <span>Step 2: Original Dataset Preview</span>
        </h2>
        <p style="color: #718096; margin-bottom: 0;">Review your dataset statistics and preview the data</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Dataset summary cards
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Rows", f"{len(df):,}")
    with col2:
        st.metric("Total Columns", len(df.columns))
    with col3:
        total_cells = df.size
        st.metric("Total Cells", f"{total_cells:,}")
    with col4:
        missing_total = df.isnull().sum().sum()
        st.metric("Missing Values", f"{missing_total:,}")
    
    # Show original dataframe if available, otherwise show current
    with st.expander("📊 View Full Dataset", expanded=False):
        if st.session_state.uploaded_original_df is not None:
            st.dataframe(st.session_state.uploaded_original_df, use_container_width=True, height=300)
        else:
            st.dataframe(df, use_container_width=True, height=300)

    # -------- STEP 2: COLUMN NAME STANDARDIZATION --------
    st.markdown("---")
    st.markdown("""
    <div style="background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
                padding: 2rem; border-radius: 15px; margin: 2rem 0;
                border-left: 5px solid #667eea; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
        <h2 style="color: #2d3748; margin-top: 0; display: flex; align-items: center;">
            <span style="font-size: 2rem; margin-right: 0.5rem;">🔤</span>
            <span>Step 3: Column Name Standardization</span>
        </h2>
        <p style="color: #718096; margin-bottom: 0;">Standardize column names for better data consistency</p>
    </div>
    """, unsafe_allow_html=True)
    
    if not st.session_state.columns_cleaned:
        # Use original columns if available, otherwise use current columns
        if st.session_state.original_columns is not None:
            original_cols = st.session_state.original_columns
        else:
            original_cols = df.columns.tolist()
            st.session_state.original_columns = original_cols
        
        cleaned_cols = [clean_column_name(c) for c in original_cols]

        col_map = pd.DataFrame({
            "Original Column Name": original_cols,
            "Standardized Column Name": cleaned_cols
        })

        st.info("💡 Column names will be standardized: lowercase, special characters removed, spaces replaced with underscores")
        
        with st.expander("📋 View Column Name Mapping", expanded=True):
            st.dataframe(col_map, use_container_width=True, height=200)

        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("✅ Accept Column Name Changes", use_container_width=True, type="primary"):
                # Check for duplicate column names after cleaning
                if len(cleaned_cols) != len(set(cleaned_cols)):
                    st.warning("⚠️ Warning: Some column names will be duplicated after cleaning. Pandas will add suffixes.")
                
                df.columns = cleaned_cols
                st.session_state.df = df
                st.session_state.columns_cleaned = True
                st.success("✅ Column names standardized successfully!")
                st.rerun()  # Rerun to refresh the UI
        with col2:
            if st.button("⏭️ Skip Column Cleaning", use_container_width=True):
                st.session_state.columns_cleaned = True
                st.info("Column name cleaning skipped")
                st.rerun()
    else:
        st.success("✅ Column names have been standardized")
        with st.expander("📋 View Current Column Names"):
            current_cols = pd.DataFrame({
                "Column Name": st.session_state.df.columns.tolist()
            })
            st.dataframe(current_cols, use_container_width=True)

    # (Rename and manual Delete controls removed per user request)

    # -------- STEP 3: MISSING VALUE ANALYSIS --------
    st.markdown("---")
    st.markdown("""
    <div style="background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
                padding: 2rem; border-radius: 15px; margin: 2rem 0;
                border-left: 5px solid #667eea; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
        <h2 style="color: #2d3748; margin-top: 0; display: flex; align-items: center;">
            <span style="font-size: 2rem; margin-right: 0.5rem;">🔍</span>
            <span>Step 4: Missing Value Analysis</span>
        </h2>
        <p style="color: #718096; margin-bottom: 0;">Analyze and identify missing values in your dataset</p>
    </div>
    """, unsafe_allow_html=True)

    missing_summary = []

    # Use the current dataframe from session state for analysis.
    # Create a local copy with snake_case column names for consistent analysis and display
    # without overwriting the user's dataframe unless they explicitly accept column cleaning.
    current_df = st.session_state.df
    analysis_df = current_df.copy()
    try:
        analysis_df.columns = [clean_column_name(c) for c in analysis_df.columns]
    except Exception:
        # Fallback: if cleaning fails for any reason, keep original column names
        analysis_df = current_df.copy()

    for col in analysis_df.columns:
        missing_count = analysis_df[col].isnull().sum()
        dtype = "Numeric" if pd.api.types.is_numeric_dtype(analysis_df[col]) else "Text"
        total_rows = len(analysis_df)
        missing_pct = (missing_count / total_rows * 100) if total_rows > 0 else 0

        if missing_count > 0:
            missing_summary.append({
                "Column Name": col,
                "Data Type": dtype,
                "Missing Values": missing_count,
                "Missing %": f"{missing_pct:.2f}%",
                "Total Rows": total_rows
            })

    # Check if dataframe is empty
    if len(current_df) == 0:
        st.warning("⚠️ The dataset is empty. Please upload a file with data.")
    elif len(missing_summary) == 0:
        st.success("🎉 No missing values detected! Your data is clean.")
    else:
        missing_df = pd.DataFrame(missing_summary)
        
        # Visual summary
        total_missing = sum([row["Missing Values"] for row in missing_summary])
        total_cells = current_df.size
        missing_percentage = (total_missing / total_cells * 100) if total_cells > 0 else 0
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Columns with Missing Values", len(missing_summary))
        with col2:
            st.metric("Total Missing Cells", f"{total_missing:,} ({missing_percentage:.2f}%)")
        
        # Progress bar
        st.markdown(f"""
        <div class="progress-bar">
            <div class="progress-fill" style="width: {100-missing_percentage}%"></div>
        </div>
        <p style="text-align: center; margin-top: 0.5rem;">Data Completeness: {100-missing_percentage:.2f}%</p>
        """, unsafe_allow_html=True)
        
        st.markdown("#### 📊 Missing Values by Column")
        st.dataframe(missing_df, use_container_width=True, height=200)

        # -------- STEP 4: AI SUGGESTIONS --------
        st.markdown("---")
        st.markdown("""
        <div style="background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
                    padding: 2rem; border-radius: 15px; margin: 2rem 0;
                    border-left: 5px solid #667eea; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
            <h2 style="color: #2d3748; margin-top: 0; display: flex; align-items: center;">
                <span style="font-size: 2rem; margin-right: 0.5rem;">🤖</span>
                <span>Step 5: AI Cleaning Suggestions</span>
            </h2>
            <p style="color: #718096; margin-bottom: 0;">Review AI recommendations and choose cleaning methods for each column</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div style="background: linear-gradient(135deg, #d1ecf1 0%, #bee5eb 100%);
                    padding: 1.2rem; border-radius: 12px; border-left: 4px solid #17a2b8;
                    margin: 1rem 0; box-shadow: 0 2px 10px rgba(23, 162, 184, 0.1);">
            <div style="display: flex; align-items: center;">
                <span style="font-size: 1.5rem; margin-right: 0.8rem;">💡</span>
                <span style="color: #0c5460; font-weight: 500;">Review AI recommendations and choose cleaning methods for each column with missing values</span>
            </div>
        </div>
        """, unsafe_allow_html=True)

        cleaning_choices = {}
        type_choices = {}  # Store integer/float preference for numeric columns

        for idx, row in enumerate(missing_summary):
            col = row["Column Name"]
            dtype = row["Data Type"]
            missing_count = row["Missing Values"]

            with st.container():
                st.markdown(f"#### Column {idx+1}: `{col}`")
                
                col1, col2 = st.columns([2, 1])
                with col1:
                    if dtype == "Numeric":
                        ai_suggestion = "Median (recommended to reduce outliers)"
                        options = ["Mean", "Median", "Mode", "Delete Rows", "Keep As Is"]
                        st.markdown(f"**Data Type:** 🔢 Numeric | **Missing:** {missing_count} values")
                    else:
                        ai_suggestion = "Mode (most frequent value)"
                        options = ["Mode", "Fill with 'Unknown'", "Delete Rows", "Keep As Is"]
                        st.markdown(f"**Data Type:** 📝 Text | **Missing:** {missing_count} values")
                    
                    st.markdown(f"**🤖 AI Recommendation:** {ai_suggestion}")
                
                with col2:
                    choice = st.selectbox(
                        f"Choose method",
                        options,
                        key=col,
                        label_visibility="collapsed"
                    )

                cleaning_choices[col] = choice
                
                # Add integer/float selection for numeric columns when Mean or Median is selected
                if dtype == "Numeric" and choice in ["Mean", "Median"]:
                    type_choice = st.radio(
                        f"Fill type for `{col}`:",
                        ["Integer", "Float"],
                        key=f"type_{col}",
                        horizontal=True,
                        index=1  # Default to Float
                    )
                    type_choices[col] = type_choice
                
                st.markdown("---")

        # -------- STEP 5: APPLY CLEANING --------
        st.markdown("---")
        st.markdown("""
        <div style="text-align: center; padding: 2rem 0;">
            <h2 style="color: #2d3748; margin: 0; display: flex; align-items: center; justify-content: center;">
                <span style="font-size: 2rem; margin-right: 0.5rem;">🚀</span>
                <span>Ready to Clean!</span>
            </h2>
            <p style="color: #718096; margin-top: 0.5rem;">Click the button below to apply all selected cleaning methods</p>
        </div>
        """, unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            if st.button("✨ Apply Cleaning", use_container_width=True, type="primary"):
                # Use the current dataframe from session state
                df = st.session_state.df.copy()
                
                rows_deleted = 0
                cells_modified = 0

                for col, method in cleaning_choices.items():
                    # The UI/analysis uses snake_case column names (analysis_df). The
                    # stored dataframe (`df`) may still have original column names
                    # (e.g., 'Age' or 'Purchase Amount (USD)'). Try to map the
                    # snake_case name back to the original column name before
                    # skipping.
                    target_col = col
                    if col not in df.columns:
                        # find the first original column whose cleaned name matches
                        matches = [c for c in df.columns if clean_column_name(c) == col]
                        if len(matches) > 0:
                            target_col = matches[0]
                            st.info(f"Mapping analysis column '{col}' -> original column '{target_col}'")
                        else:
                            st.warning(f"Column '{col}' not found. Skipping...")
                            continue

                    if method == "Keep As Is":
                        # Skip this column - don't modify it
                        continue

                    elif method == "Mean":
                        if not pd.api.types.is_numeric_dtype(df[target_col]):
                            st.warning(f"Cannot calculate mean for non-numeric column '{target_col}'. Skipping...")
                            continue
                        value = df[target_col].mean()
                        if pd.notna(value):
                            # Convert to integer or float based on user selection
                            fill_type = type_choices.get(col, "Float")  # Default to Float if not specified
                            if fill_type == "Integer":
                                value = int(round(value))
                            else:
                                value = float(value)
                            missing_before = df[target_col].isnull().sum()
                            df[target_col].fillna(value, inplace=True)
                            cells_modified += missing_before
                        else:
                            st.warning(f"Cannot calculate mean for column '{col}' (all values are NaN). Skipping...")

                    elif method == "Median":
                        if not pd.api.types.is_numeric_dtype(df[target_col]):
                            st.warning(f"Cannot calculate median for non-numeric column '{target_col}'. Skipping...")
                            continue
                        value = df[target_col].median()
                        if pd.notna(value):
                            # Convert to integer or float based on user selection
                            fill_type = type_choices.get(col, "Float")  # Default to Float if not specified
                            if fill_type == "Integer":
                                value = int(round(value))
                            else:
                                value = float(value)
                            missing_before = df[target_col].isnull().sum()
                            df[target_col].fillna(value, inplace=True)
                            cells_modified += missing_before
                        else:
                            st.warning(f"Cannot calculate median for column '{col}' (all values are NaN). Skipping...")

                    elif method == "Mode":
                        # Remove NaN values before calculating mode
                        non_null_values = df[target_col].dropna()
                        if len(non_null_values) == 0:
                            st.warning(f"Cannot calculate mode for column '{target_col}' (all values are NaN). Skipping...")
                            continue
                        mode_values = df[target_col].mode()
                        if len(mode_values) > 0:
                            value = mode_values[0]
                            missing_before = df[target_col].isnull().sum()
                            df[target_col].fillna(value, inplace=True)
                            cells_modified += missing_before
                        else:
                            st.warning(f"Cannot calculate mode for column '{col}' (no mode available). Skipping...")

                    elif method == "Fill with 'Unknown'":
                        missing_before = df[target_col].isnull().sum()
                        df[target_col].fillna("Unknown", inplace=True)
                        cells_modified += missing_before

                    elif method == "Delete Rows":
                        before = len(df)
                        df.dropna(subset=[target_col], inplace=True)
                        rows_deleted += before - len(df)

                st.session_state.df = df
                # After applying cleaning methods, convert final column names to snake_case
                # so the final dataset uses consistent pandas-style names.
                try:
                    new_cols = []
                    seen = {}
                    for c in df.columns:
                        base = clean_column_name(c)
                        if base in seen:
                            seen[base] += 1
                            new_name = f"{base}_{seen[base]}"
                        else:
                            seen[base] = 1
                            new_name = base
                        new_cols.append(new_name)
                    df.columns = new_cols
                except Exception:
                    # If something goes wrong with cleaning, keep original names
                    pass

                st.session_state.df = df
                st.session_state.columns_cleaned = True
                st.session_state.cleaning_done = True

                # Show summary
                if cells_modified > 0 or rows_deleted > 0:
                    summary_msg = f"✅ Data cleaning applied successfully!\n"
                    if cells_modified > 0:
                        summary_msg += f"• {cells_modified} missing values filled\n"
                    if rows_deleted > 0:
                        summary_msg += f"• {rows_deleted} rows deleted"
                    st.success(summary_msg)
                else:
                    st.info("No changes were applied (all columns set to 'Keep As Is' or no valid cleaning method selected).")

    # -------- FINAL OUTPUT --------
    if st.session_state.cleaning_done:
        st.markdown("---")
        st.markdown("""
        <div style="background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
                    padding: 3rem 2rem; border-radius: 20px; margin: 2rem 0;
                    text-align: center; box-shadow: 0 10px 40px rgba(40, 167, 69, 0.2);
                    border: 2px solid #28a745;">
            <h1 style="color: #155724; margin: 0; font-size: 2.5rem;">
                <span style="font-size: 3rem; margin-right: 0.5rem;">🎉</span>
                Cleaning Complete!
            </h1>
            <p style="color: #155724; margin-top: 1rem; font-size: 1.1rem;">Your data has been successfully cleaned and is ready to download</p>
        </div>
        """, unsafe_allow_html=True)
        
        # -------- DATA QUALITY SCORE --------
        # Build final_df from current working df
        final_df = st.session_state.df.copy()
        total_cells = final_df.size
        missing_after = final_df.isnull().sum().sum()
        quality_score = round(100 - (missing_after / total_cells * 100), 2) if total_cells > 0 else 100
        
        # Quality score with visual
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown("### 📈 Data Quality Score")
            st.metric("Quality Score", f"{quality_score}%", delta=f"{quality_score-50:.1f}%")
            
            # Quality progress bar
            quality_color = "#28a745" if quality_score >= 90 else "#ffc107" if quality_score >= 70 else "#dc3545"
            st.markdown(f"""
            <div class="progress-bar">
                <div class="progress-fill" style="width: {quality_score}%; background: {quality_color};"></div>
            </div>
            """, unsafe_allow_html=True)
        
        # Dataset comparison
        st.markdown("### 📊 Dataset Comparison")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Rows", f"{len(final_df):,}", delta=f"{len(final_df) - len(st.session_state.uploaded_original_df) if st.session_state.uploaded_original_df is not None else 0}")
        with col2:
            st.metric("Columns", len(final_df.columns))
        with col3:
            st.metric("Missing Values", f"{missing_after:,}", delta=f"{missing_after - (st.session_state.uploaded_original_df.isnull().sum().sum() if st.session_state.uploaded_original_df is not None else 0)}", delta_color="inverse")
        with col4:
            st.metric("Data Completeness", f"{quality_score}%")
        
        # Final dataset preview
        st.markdown("### 📋 Final Cleaned Dataset")
        with st.expander("View Cleaned Data", expanded=True):
            st.dataframe(final_df, use_container_width=True, height=400)

        # -------- CLEANING REPORT --------
        st.markdown("### 📝 Cleaning Report")
        report_col1, report_col2 = st.columns(2)
        with report_col1:
            st.markdown("""
            <div class="success-box">
                <h4>✅ Completed Steps</h4>
                <ul>
                    <li>Column name standardization applied</li>
                    <li>Missing values handled using AI-assisted rules</li>
                    <li>Human-in-the-loop decision making enabled</li>
                </ul>
            </div>
            """, unsafe_allow_html=True)
        with report_col2:
            st.markdown(f"""
            <div class="info-box">
                <h4>📊 Statistics</h4>
                <ul>
                    <li>Total cells processed: {total_cells:,}</li>
                    <li>Missing values remaining: {missing_after:,}</li>
                    <li>Data quality: {quality_score}%</li>
                </ul>
            </div>
            """, unsafe_allow_html=True)

        # -------- DOWNLOAD CLEANED EXCEL --------
        st.markdown("---")
        st.markdown("### 💾 Download Cleaned Excel File")
        
        output = BytesIO()
        try:
            with st.spinner("Preparing download..."):
                with pd.ExcelWriter(output, engine='openpyxl') as writer:
                    st.session_state.df.to_excel(writer, index=False, sheet_name='Cleaned Data')
                output.seek(0)  # Reset pointer to beginning of file
                
                col1, col2, col3 = st.columns([1, 2, 1])
                with col2:
                    st.download_button(
                        label="📥 Download Cleaned Excel",
                        data=output.getvalue(),
                        file_name="cleaned_data.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        use_container_width=True,
                        type="primary"
                    )
        except Exception as e:
            st.error(f"❌ Error creating Excel file: {str(e)}")