import streamlit as st

def load_css(is_dark_mode=False):
    """Validates and loads the custom CSS for the application."""
    
    # Define color palettes
    if is_dark_mode:
        # DARK MODE PALETTE
        variables = """
            /* Core Colors - Modern Indigo/Violet Palette */
            --primary: #818cf8; /* Lighter primary for dark mode */
            --primary-dark: #6366f1;
            --primary-light: #a5b4fc;
            --secondary: #f472b6;
            --accent: #a78bfa;
            
            /* Backgrounds */
            --bg-body: #0f172a;      /* Slate 900 */
            --bg-card: #1e293b;      /* Slate 800 */
            --bg-sidebar: #1e293b;   /* Slate 800 */
            
            /* Text */
            --text-main: #e2e8f0;    /* Slate 200 */
            --text-light: #94a3b8;   /* Slate 400 */
            --text-heading: #f8fafc; /* Slate 50 */
            
            /* Borders & Shadows */
            --border-subtle: #334155; /* Slate 700 */
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.3);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.4);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.4);
            --shadow-glow: 0 0 20px rgba(99, 102, 241, 0.25);
            
            /* Gradient Overrides */
            --bg-gradient-start: #0f172a;
            --bg-gradient-end: #1e293b;

            /* Success Banner - Dark Mode (Emerald Green) */
            --success-bg: rgba(16, 185, 129, 0.15); /* Translucent Emerald */
            --success-border: #10b981;              /* Vibrant Emerald */
            --success-title: #34d399;               /* Bright Emerald */
            --success-text: #ffffff;                /* Pure White for max contrast */
            --success-shadow: 0 0 15px rgba(16, 185, 129, 0.3); /* Glow */

            /* Pro Tips */
            --tip-bg: #1e293b;
            --tip-border: #3b82f6;
            --tip-title: #60a5fa; /* Light Blue */
            --tip-text: #bfdbfe;  /* Very Light Blue */

            /* File Uploader Specific */
            --uploader-text: #ffffff;
            
            /* Input Fields */
            --input-bg: #f8fafc;
            --input-text: #000000;
        """
    else:
        # LIGHT MODE PALETTE
        variables = """
            /* Core Colors - Modern Indigo/Violet Palette */
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --primary-light: #818cf8;
            --secondary: #ec4899;
            --accent: #8b5cf6;
            
            /* Backgrounds */
            --bg-body: #f8fafc;
            --bg-card: #ffffff;
            --bg-sidebar: #ffffff;
            
            /* Text */
            --text-main: #1e293b;
            --text-light: #64748b;
            --text-heading: #0f172a;
            
            /* Borders & Shadows */
            --border-subtle: #e2e8f0;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --shadow-glow: 0 0 20px rgba(99, 102, 241, 0.15);
            
            /* Gradient Overrides */
            --bg-gradient-start: #f5f7fa;
            --bg-gradient-end: #c3cfe2;

            /* Success Banner - Light Mode (Original Green) */
            --success-bg: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            --success-border: #28a745;
            --success-title: #155724;
            --success-text: #155724;

            /* Pro Tips - Light Mode (Blue) */
            --tip-bg: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
            --tip-border: #2196f3;
            --tip-title: #1976d2;
            --tip-text: #0d47a1;

            /* File Uploader Specific */
            --uploader-text: var(--text-main);

            /* Input Fields */
            --input-bg: #ffffff;
            --input-text: #000000;
        """

    st.markdown(f"""
    <style>
        /* -------------------------------------------------------------------------- */
        /*                                 GOOGLE FONTS                               */
        /* -------------------------------------------------------------------------- */
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap');

        /* -------------------------------------------------------------------------- */
        /*                                  VARIABLES                                 */
        /* -------------------------------------------------------------------------- */
        :root {{
            {variables}
        }}

        /* -------------------------------------------------------------------------- */
        /*                                GLOBAL RESETS                               */
        /* -------------------------------------------------------------------------- */
        * {{
            font-family: 'Inter', sans-serif;
            box-sizing: border-box;
            transition: background-color 0.3s ease, color 0.3s ease;
        }}
        
        h1, h2, h3, h4, h5, h6 {{
            font-family: 'Outfit', sans-serif;
            color: var(--text-heading) !important;
            letter-spacing: -0.025em;
        }}

        /* -------------------------------------------------------------------------- */
        /*                             STREAMLIT OVERRIDES                            */
        /* -------------------------------------------------------------------------- */
        
        /* App Background */
        /* App Background */
        .stApp {{
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%);
            background-attachment: fixed;
            color: var(--text-main) !important;
        }}

        /* Force Text Colors for Streamlit Components */
        p, .stMarkdown, label, .stTextInput > label, .stNumberInput > label, .stSelectbox > label, .stFileUploader > label {{
            color: var(--text-main) !important;
        }}
        
        h1, h2, h3, h4, h5, h6, .stHeading {{
            color: var(--text-heading) !important;
        }}

        /* Input Fields Text Color */
        .stTextInput input, .stNumberInput input {{
            color: var(--input-text) !important;
            background-color: var(--input-bg) !important;
            caret-color: var(--primary);
        }}

        /* Main Container */
        .main .block-container {{
            max-width: 1280px;
            padding-top: 2rem;
            padding-bottom: 4rem;
        }}

        /* Sidebar */
        section[data-testid="stSidebar"] {{
            background-color: var(--bg-sidebar);
            border-right: 1px solid var(--border-subtle);
        }}

        /* Buttons (Primary) */
        .stButton > button {{
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 0.6rem 1.2rem;
            font-weight: 600;
            transition: all 0.2s ease;
            box-shadow: var(--shadow-sm);
        }}
        .stButton > button:hover {{
            transform: translateY(-1px);
            box-shadow: var(--shadow-glow);
        }}
        .stButton > button:active {{
            transform: translateY(0);
        }}

        /* File Uploader */
        [data-testid="stFileUploader"] {{
            padding: 2rem;
            border: 2px dashed var(--border-subtle);
            border-radius: 12px;
            background: var(--bg-card);
            text-align: center;
            transition: all 0.3s ease;
        }}
        [data-testid="stFileUploader"]:hover {{
            border-color: var(--primary);
            background: rgba(99, 102, 241, 0.05);
        }}
        [data-testid="stFileUploader"] p {{
             color: var(--text-main);
        }}

        /* Dataframes */
        .stDataFrame {{
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid var(--border-subtle);
            box-shadow: var(--shadow-sm);
        }}

        /* Metrics */
        [data-testid="stMetricValue"] {{
            color: var(--primary);
            font-family: 'Outfit', sans-serif;
            font-weight: 700;
        }}
        [data-testid="stMetricLabel"] {{
            color: var(--text-light);
            font-size: 0.875rem;
        }}

        /* Expander */
        .streamlit-expanderHeader {{
            color: var(--text-main);
            background-color: var(--bg-card);
        }}

        /* -------------------------------------------------------------------------- */
        /*                             CUSTOM COMPONENTS                              */
        /* -------------------------------------------------------------------------- */
        
        /* Animations */
        @keyframes fadeInUp {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        /* Hero Section */
        .hero-container {{
            animation: fadeInUp 0.8s ease-out;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #e195eb 100%);
            border-radius: 20px;
            padding: 4rem 2rem;
            color: white;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            margin-bottom: 3rem;
            text-align: center;
        }}
        
        .hero-orb {{
            position: absolute;
            width: 300px;
            height: 300px;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
            border-radius: 50%;
            top: -50px;
            right: -50px;
            backdrop-filter: blur(10px);
            opacity: 0.5;
            z-index: 1;
        }}

        .hero-orb-small {{
            position: absolute;
            width: 150px;
            height: 150px;
            background: rgba(255,255,255,0.05);
            border-radius: 50%;
            bottom: -30px;
            left: -30px;
            z-index: 1;
        }}

        .hero-content {{
            position: relative;
            z-index: 10;
        }}

        .hero-title {{
            font-size: 3.5rem;
            font-weight: 800;
            margin: 0;
            letter-spacing: -1px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
        }}
        
        .hero-subtitle {{
            font-size: 1.2rem;
            color: rgba(255, 255, 255, 0.95);
            max-width: 1000px;
            margin: 1.5rem auto 0;
            font-weight: 500;
            line-height: 1.6;
            text-align: center;
            padding-left: 4rem; /* Calculated optical alignment: (IconWidth + Gap) / 2 shift */
        }}

        /* Feature Card */
        .feature-card {{
            background: var(--bg-card);
            border-radius: 16px;
            padding: 1rem;
            border: 1px solid var(--border-subtle);
            box-shadow: var(--shadow-md);
            transition: all 0.3s ease;
            height: 100%;
            min-height: 160px; /* Enforce consistent height */
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
        }}
        .feature-card:hover {{
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
            border-color: var(--primary-light);
        }}
        .card-icon {{
            font-size: 1.8rem;
            margin-bottom: 0.75rem;
            display: inline-block;
            background: rgba(99, 102, 241, 0.1);
            padding: 0.6rem;
            border-radius: 12px;
        }}
        .card-title {{
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
            color: var(--text-main);
            white-space: nowrap; /* Prevent text wrapping */
        }}
        .card-desc {{
            font-size: 0.9rem;
            color: var(--text-light);
            line-height: 1.5;
        }}

        /* Status Badge */
        .status-badge {{
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }}
        .status-success {{ background: #dcfce7; color: #166534; }}
        .status-warning {{ background: #fef9c3; color: #854d0e; }}
        .status-error {{ background: #fee2e2; color: #991b1b; }}
        
        /* Modern Step Indicator */
        .step-indicator {{
            display: flex;
            align-items: center;
            margin-bottom: 2rem;
            overflow-x: auto;
            padding-bottom: 1rem;
        }}
        .step-item {{
            display: flex;
            align-items: center;
            opacity: 0.5;
            flex-shrink: 0;
        }}
        .step-item.active {{ opacity: 1; }}
        .step-number {{
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            margin-right: 0.75rem;
        }}
        .step-label {{
            font-weight: 600;
            color: var(--text-heading);
            margin-right: 2rem;
        }}
        .step-line {{
            height: 2px;
            width: 50px;
            background: var(--border-subtle);
            margin-right: 1rem;
        }}


        /* -------------------------------------------------------------------------- */
        /*                                 AUTH STYLES                                */
        /* -------------------------------------------------------------------------- */
        
        /* Scale the middle column to look like a Login Card */
        div[data-testid="stColumn"]:nth-of-type(2) > div[data-testid="stVerticalBlockBorderWrapper"] > div {{
            background: var(--bg-card); /* Keep variable here if possible, or use explicit */
            padding: 3rem;
            border-radius: 24px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--border-subtle);
            backdrop-filter: blur(10px);
        }}
        
        .auth-header {{
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-heading);
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}

        .auth-subtext {{
            color: var(--text-light);
            font-size: 0.95rem;
            margin-bottom: 2rem;
        }}
        
        /* Style standard Streamlit inputs for Login */
        .stTextInput > div > div > input {{
            background-color: var(--bg-body);
            color: var(--text-main);
            border: 1px solid var(--border-subtle);
            border-radius: 12px;
            padding: 0.5rem 1rem;
            font-size: 1rem;
            transition: all 0.2s;
        }}
        .stTextInput > div > div > input:focus {{
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }}

        /* Hide the native browser password reveal button (the "duplicate eye") */
        input[type="password"]::-ms-reveal,
        input[type="password"]::-ms-clear {{
            display: none;
        }}

        /* Hide "Press Enter to apply" tooltips/text */
        div[data-testid="InputInstructions"] {{
            display: none !important;
        }}

        /* -------------------------------------------------------------------------- */
        /*                           COMPONENT FIXES                                  */
        /* -------------------------------------------------------------------------- */
        
        /* Expander Fixes */
        div[data-testid="stExpander"] details > summary {{
            background-color: var(--bg-card) !important;
            color: var(--text-main) !important;
            border: 1px solid var(--border-subtle) !important;
            border-radius: 8px;
        }}
        div[data-testid="stExpander"] details > summary:hover {{
            color: var(--primary) !important;
        }}
        div[data-testid="stExpander"] details {{
            border-color: var(--border-subtle) !important;
        }}

        /* File Uploader File Name Fix */
        [data-testid="stFileUploader"] div[data-testid="stMarkdownContainer"] p {{
            color: var(--text-main) !important;
        }}
        [data-testid="stFileUploader"] small {{
            color: var(--text-light) !important;
        }}

        /* Success Banner */
        .success-banner {{
            background: var(--success-bg);
            padding: 3rem 2rem; 
            border-radius: 20px; 
            margin: 2rem 0;
            text-align: center; 
            box-shadow: var(--shadow-lg);
            border: 2px solid var(--success-border);
            animation: fadeInUp 0.5s ease-out;
        }}
        .success-banner h1 {{
            color: var(--success-title) !important;
            font-size: 2.5rem !important;
            margin-bottom: 0.5rem !important;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }}
        .success-banner p {{
            color: var(--success-text) !important;
            font-size: 1.1rem !important;
        }}

        /* Pro Tips Box */
        .pro-tips {{
            background: var(--tip-bg);
            padding: 1.2rem; 
            border-radius: 12px; 
            border-left: 4px solid var(--tip-border);
            margin-bottom: 30px;
        }}
        .pro-tips h4 {{
            color: var(--tip-title) !important;
            margin-top: 0 !important;
            margin-bottom: 0.8rem !important;
        }}
        .pro-tips ul {{
            color: var(--tip-text) !important;
            margin: 0 !important;
            padding-left: 1.2rem !important;
            font-size: 0.9rem !important;
        }}
        .pro-tips li {{
            margin-bottom: 0.5rem !important;
            color: var(--tip-text) !important;
        }}

        /* -------------------------------------------------------------------------- */
        /*                           FILE UPLOADER FIXES                              */
        /* -------------------------------------------------------------------------- */

        /* Generic label */
        [data-testid="stFileUploader"] label {{
            color: var(--text-heading) !important;
        }}

        /* Dropzone Box */
        [data-testid="stFileUploaderDropzone"] {{
            background-color: var(--bg-card) !important;
            border: 2px dashed var(--border-subtle) !important;
            border-radius: 12px;
        }}

        /* "Drag and drop file here" text */
        [data-testid="stFileUploaderDropzoneInstructions"] p {{
            color: var(--text-main) !important;
        }}
        [data-testid="stFileUploaderDropzoneInstructions"] small {{
            color: var(--text-light) !important;
        }}

        /* Browse files button */
        [data-testid="stFileUploader"] button {{
            background-color: var(--bg-card) !important;
            color: var(--text-main) !important;
            border: 1px solid var(--border-subtle) !important;
            border-radius: 8px !important;
        }}
        [data-testid="stFileUploader"] button:hover {{
            color: var(--primary) !important;
            border-color: var(--primary) !important;
        }}

        /* UPLOADED FILENAME (The core fix) */
        /* Specifically target the filename text after upload */
        [data-testid="stFileUploader"] section[data-testid="stFileUploaderFileName"],
        [data-testid="stFileUploader"] section[data-testid="stFileUploaderFileName"] span,
        [data-testid="stFileUploader"] section div span,
        [data-testid="stFileUploaderFileName"] {{
            color: var(--uploader-text) !important;
            font-weight: 500 !important;
        }}

        /* File metadata (size) */
        [data-testid="stFileUploader"] section[data-testid="stFileUploaderFileName"] + div,
        [data-testid="stFileUploader"] small {{
            color: var(--uploader-text) !important;
            opacity: 0.7;
        }}

        /* -------------------------------------------------------------------------- */
        /*                          AUTHENTICATION UI                                 */
        /* -------------------------------------------------------------------------- */
        
        /* Auth Divider (OR) */
        .auth-divider {{
            display: flex;
            align-items: center;
            text-align: center;
            margin: 1.5rem 0;
            color: var(--text-light);
        }}
        .auth-divider::before, .auth-divider::after {{
            content: '';
            flex: 1;
            border-bottom: 1px solid var(--border-subtle);
        }}
        .auth-divider:not(:empty)::before {{
            margin-right: 1rem;
        }}
        .auth-divider:not(:empty)::after {{
            margin-left: 1rem;
        }}

        /* Google button integration with real st.button */
        .google-btn-container {{
            margin-bottom: 1rem !important;
        }}
        
        .google-btn-container [data-testid="stBaseButton-secondary"] {{
            background-color: var(--bg-card) !important;
            color: var(--text-main) !important;
            border: 1px solid var(--border-subtle) !important;
            border-radius: 12px !important;
            padding: 0.5rem 1rem !important;
            font-weight: 500 !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            box-shadow: var(--shadow-sm) !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
        }}

        .google-btn-container [data-testid="stBaseButton-secondary"]:hover {{
            background-color: var(--bg-hover) !important;
            border-color: var(--primary) !important;
            box-shadow: var(--shadow-md) !important;
            transform: translateY(-1px) !important;
        }}
        
        .google-btn-container [data-testid="stBaseButton-secondary"]::before {{
            content: "";
            background-image: url("https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png");
            background-size: contain;
            background-repeat: no-repeat;
            width: 20px;
            height: 20px;
            margin-right: 12px;
            display: inline-block;
        /* Vibrant Success Banner */
        .success-banner {{
            background: var(--success-bg) !important;
            border: 1.5px solid var(--success-border) !important;
            color: var(--success-text) !important;
            padding: 1rem 1.2rem !important;
            border-radius: 12px !important;
            margin: 1rem 0 !important;
            display: flex !important;
            align-items: center !important;
            box-shadow: var(--success-shadow) !important;
            animation: fadeIn 0.5s ease-out;
        }}
        .success-banner-icon {{
            font-size: 1.4rem;
            margin-right: 12px;
        }}
        
        .success-banner h1, .success-banner span {{
            color: var(--success-title) !important;
            margin-bottom: 0.5rem !important;
        }}
        .success-banner p {{
            color: var(--success-text) !important;
            margin: 0 !important;
            opacity: 0.9;
        }}
        
        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(5px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

    </style>
    """, unsafe_allow_html=True)
 
def success_banner(message):
    """Returns HTML for a custom vibrant success banner."""
    return f'''
    <div class="success-banner">
        <span class="success-banner-icon">✅</span>
        <div>{message}</div>
    </div>
    '''

def hero_section():
    """Renders the simplified, modern hero section."""
    st.markdown("""
    <div class="hero-container">
        <div class="hero-orb"></div>
        <div class="hero-orb-small"></div>
        <div class="hero-content">
            <h1 class="hero-title">
                <span style="font-size: 3rem;">🧹</span> 
                AI-Based Automatic Data Cleaning Tool
            </h1>
            <p class="hero-subtitle">Upload an Excel file and clean it without writing any code — fast, safe, and human-in-the-loop.</p>
        </div>
    </div>
    """, unsafe_allow_html=True)

def feature_card(icon, title, description):
    """Renders a feature card."""
    return f"""
    <div class="feature-card">
        <div class="card-icon">{icon}</div>
        <div class="card-title">{title}</div>
        <div class="card-desc">{description}</div>
    </div>
    """

def step_header(number, title, subtitle):
    """Renders a consistent step header."""
    st.markdown(f"""
    <div style="margin: 3rem 0 1.5rem 0;">
        <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
            <div style="
                background: linear-gradient(135deg, var(--primary), var(--secondary));
                color: white;
                width: 40px; height: 40px;
                border-radius: 12px;
                display: flex; align-items: center; justify-content: center;
                font-weight: 800;
                font-size: 1.2rem;
                margin-right: 1rem;
                box-shadow: var(--shadow-md);
            ">{number}</div>
            <h2 style="margin: 0; font-size: 1.8rem;">{title}</h2>
        </div>
        <p style="color: var(--text-light); margin-left: 3.5rem; max-width: 600px;">{subtitle}</p>
    </div>
    """, unsafe_allow_html=True)
