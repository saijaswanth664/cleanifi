# Google OAuth2 Configuration
# Get your Client ID from: https://console.cloud.google.com/

GOOGLE_CLIENT_ID = ""  # ENTER_YOUR_CLIENT_ID_HERE
GOOGLE_CLIENT_SECRET = "" # ENTER_YOUR_CLIENT_SECRET_HERE

# Redirect URI (must match what you set in Google Cloud Console)
# For local development, this is typically:
GOOGLE_REDIRECT_URI = "http://localhost:8501"
