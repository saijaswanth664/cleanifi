\# CLEANIFI 🧹



\*\*AI-Based Automatic Data Cleaning Website\*\*  

Explainable • Human-in-the-Loop • No-Code System



---



\## 📌 Project Overview



CLEANIFI is an AI-based automatic data cleaning web application designed to help users clean Excel datasets without writing any code.  

The system follows a \*\*human-in-the-loop\*\* and \*\*explainable AI\*\* approach, allowing users to understand and control how their data is cleaned.



---



\## 🎯 Key Features



\- Excel file upload (.xlsx)

\- Automatic column name standardization (snake\_case)

\- Missing value detection

\- AI-based cleaning recommendations

\- User-selected cleaning methods:

&nbsp; - Mean

&nbsp; - Median

&nbsp; - Mode

&nbsp; - Delete Rows

&nbsp; - Fill with NaN

\- Data type confirmation (Integer / Float)

\- What-if preview before applying changes

\- Data quality score (Before \& After)

\- Light and Dark mode UI

\- Cleaned Excel file download



---



\## 🛠️ Technology Stack



\- \*\*Frontend \& Backend:\*\* Streamlit

\- \*\*Programming Language:\*\* Python

\- \*\*Data Processing:\*\* Pandas, NumPy

\- \*\*Excel Handling:\*\* OpenPyXL

\- \*\*UI Enhancements:\*\* Custom CSS

\- \*\*Logo Rendering:\*\* Pillow



---



\## 🚀 How to Run the Project



\### Step 1: Install Dependencies

```bash

pip install -r requirements.txt



